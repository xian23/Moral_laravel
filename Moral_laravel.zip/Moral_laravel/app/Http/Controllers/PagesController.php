<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function index(){
     // $title = 'Welcome To Laravel!';
    	return view('pages.index');
   }
     public function about(){
       $title = 'About Us';
    	return view('pages.about')  ;
   }
    public function mysubject(){
    	return view('pages.mysubject');
   }

     public function social(){
    	return view('pages.social');
   } 

    public function education(){
    	return view('pages.education');
   } 	

    public function phpsubject(){
    	return view('pages.phpsubject');
   } 	
}
