@extends('layouts.app')
    
@section('content')
        <h1>My Subject</h1>
        <p>List of all subjects</p>
       <br><br>
<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
</style>
</head>
<body>

<table style="width:100%">
  <caption>Subjects</caption>
  <tr>
    <th>Major Subject</th>
    <th>Minor Subject</th>
  </tr>
  <tr>
    <td>Database32</td>
    <td>Englist</td>
  </tr>
  <tr>
    <td>Php</td>
    <td>Math</td>
  </tr>
  <tr>
    <td>Php2</td>
    <td>PE</td>
  </tr>
  <tr>
    <td>Android</td>
    <td>Economics</td>
  </tr>
  <tr>
    <td>EMBEDDED</td>
    <td>Filipino</td>
  </tr>
  <tr>
    <td>ISM</td>
    <td>History</td>
  </tr>
</table>

</body>
</html>

        
@endsection