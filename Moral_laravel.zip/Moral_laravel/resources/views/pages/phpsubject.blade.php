@extends('layouts.app')
    
@section('content')
        <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	 <h1>PHP2 SUBJECT</h1>
              <div class="panel panel-default">
              	This subject is advance version it has the use of frameworks to make the work easire for the programmers or developers.This subject also focuse on th user interface and features also techniques.<BR><BR>
              
              </div>
            </div>
        </div>
    </div>
</div>
@endsection