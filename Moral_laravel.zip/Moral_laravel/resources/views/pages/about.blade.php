@extends('layouts.app')
    
@section('content')
       <center> <h1>ABOUT</h1></center>
        <p>History[LARAVEL]
Taylor Otwell created Laravel as an attempt to provide a more advanced alternative to the CodeIgniter framework, which did not provide certain features such as built-in support for user authentication and authorization. Laravel's first beta release was made available on June 9, 2011, followed by the Laravel 1 release later in the same month. Laravel 1 included built-in support for authentication, localisation, models, views, sessions, routing and other mechanisms, but lacked support for controllers that prevented it from being a true MVC framework.[1]

Laravel 2 was released in September 2011, bringing various improvements from the author and community. Major new features included the support for controllers, which made Laravel 2 a fully MVC-compliant framework, built-in support for the inversion of control (IoC) principle, and a templating system called Blade. As a downside, support for third-party packages was removed in Laravel 2.[1]

Laravel 3 was released in February 2012 with a set of new features including the command-line interface (CLI) named Artisan, built-in support for more database management systems, database migrations as a form of version control for database layouts, support for handling events, and a packaging system called Bundles. An increase of the Laravel's userbase and popularity lined up with the release of Laravel 3.[1]

Laravel 4, codenamed Illuminate, was released in May 2013. It was made as a complete rewrite of the Laravel framework, migrating its layout into a set of separate packages distributed through Composer, which serves as an application-level package manager. Such a layout improved the extendibility of Laravel 4, which was paired with its official regular release schedule spanning six months between minor point releases. Other new features in the Laravel 4 release include database seeding for the initial population of databases, support for message queues, built-in support for sending different types of email, and support for delayed deletion of database records called soft deletion.[1][11]:18–19

Laravel 5 was released in February 2015 as a result of internal changes that ended up in renumbering the then-future Laravel 4.3 release. New features in the Laravel 5 release include support for scheduling periodically executed tasks through a package called Scheduler, an abstraction layer called Flysystem that allows remote storage to be used in the same way as local file systems, improved handling of package assets through Elixir, and simplified externally handled authentication through the optional Socialite package. Laravel 5 also introduced a new internal directory tree structure for developed applications.[6]:13–14[12]

Laravel 5.1, released in June 2015, is the first release of Laravel to receive long-term support (LTS), with planned availability of bug fixes for two years and security patches for three years. LTS releases of Laravel are planned to be released every two years.[13]

Laravel 5.3, released in August 23, 2016, The new features in 5.3 are focused on improving developer speed by adding additional out of the box improvements for common tasks.[14] [15]

Laravel 5.4, released in January 24, 2017, This release has many new features, like Laravel Dusk, Laravel Mix, Blade Components and Slots, Markdown Emails, Automatic Facades, Route Improvements, Higher Order Messaging for Collections, and many others.[16]

Laravel 5.5, released in August 30, 2017</p>
        
@endsection
