@extends('layouts.app')
    
@section('content')
            <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>SOCIAL MEDIA ACCOUNTS</h1>

              <div class="panel panel-default">
              	<H3>
  				Instagram Account: hansmoral<BR><BR>
  				 Facebook Account: hans_carmel@yahoo.com<BR><BR>
              </H3>
              </div>
            </div>
        </div>
    </div>
</div>
       
@endsection
