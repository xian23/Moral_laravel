    
<?php $__env->startSection('content'); ?>
       <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>My Education</h1>

              <div class="panel panel-default">
              	<H3>
  				Elementary : Lahug Elementary School <BR><BR>
  				High School :St. Paul Collage Foundation Inc. <BR><BR>
  				College : University Of Cebu – Main Campus (Present) <BR>
  				Course : Bachelor of Science in Information Technology<BR><BR>
  				
              </H3>
              </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>