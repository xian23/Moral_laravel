<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', 'PagesController@index');
Route::get('/about', 'PagesController@about');
Route::get('/mysubject', 'PagesController@mysubject');
Route::get('/social', 'PagesController@social');
Route::get('/education', 'PagesController@education');
Route::get('/phpsubject', 'PagesController@phpsubject');
*/

Route::get('/', function (){
  return View::make('pages.index');

});

Route::get('/about', function (){
    return View::make('pages.about');
  
  });

  Route::get('/mysubject', function (){
    return View::make('pages.mysubject');
  
});

Route::get('/social', function (){
    return View::make('pages.social');
  
});

Route::get('/education', function (){
    return View::make('pages.education');
  
});

Route::get('/phpsubject', function (){
    return View::make('pages.phpsubject');
  
});

Auth::routes();

Route::get('/dashboard', 'DashboardController@index')->name('dashboard');
